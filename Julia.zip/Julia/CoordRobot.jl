using HorizonSideRobots

mutable struct CoordRobot #обертка робота
    robot::Robot#сам робот
    x::Int #координаты робота
    y::Int
    allowPaint::Bool #разрешение красить(если == false, то робот не сможет ставить маркеры)
    update::Function #функция, которая выполняется роботом каждый шаг
end

#конструктор робота, ставит стандартные значения всему кроме самого робота( ()->0 это пустая функция)
function CoordRobot(robot::Robot)
    return CoordRobot(robot, 0, 0, true, ()->0)
end

# устанавливает функцию обновления робота, если не ставить новую функция, то будет поставлена пустая функция
function SetUpdateFunc(robot::CoordRobot, func = ()->0)
    robot.update = func
end

#ставит координаты на 0 0
function resetCoords(robot::CoordRobot)
    robot.x = 0
    robot.y = 0
end

#считает координаты начальной клетки из пути до угла
function goHomeCoords(moves)
    homeX = 0
    homeY = 0
    for move in moves 
        if move[1] == Nord
            homeY += move[2]
        elseif move[1] == Sud
            homeY -= move[2]
        elseif move[1] == West
            homeX += move[2]
        elseif move[1] == Ost
            homeX -= move[2]
        end
    end
    return (homeX, homeY)
end

#обертка move!, обновляет координаты и выполняет функцию обновления
function HorizonSideRobots.move!(robot::CoordRobot, side)
    if side == Nord
        robot.y -= 1
    elseif side == Sud
        robot.y += 1
    elseif side == West
        robot.x -= 1
    elseif side == Ost
        robot.x += 1
    end
    move!(robot.robot, side)
    robot.update()
end

#обертка putmarker!, ставит маркер, только если allowPaint == true
function HorizonSideRobots.putmarker!(robot::CoordRobot)
    if robot.allowPaint
        putmarker!(robot.robot)
    end
end

function HorizonSideRobots.isborder(robot::CoordRobot, side)
    return isborder(robot.robot, side)
end

function HorizonSideRobots.ismarker(robot::CoordRobot)
    return ismarker(robot.robot)
end