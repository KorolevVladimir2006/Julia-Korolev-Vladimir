using HorizonSideRobots

#поворот стороны на steps шагов против часовой
function rotate(side, steps)
    side = Int(side)+steps
    if side >= 0
        return HorizonSide(side%4)
    else
        return HorizonSide(4-side)
    end
end

#возвращает список всех стен, которых касается
function GetBorders(robot)
    borders = []
    for side in [Ost, Sud, West, Nord]
        if isborder(robot, side)
            push!(borders, side)
        end
    end
    return borders
end

#двигается steps шагов, если lay = true, то оставляет след из маркеров
function goSteps(robot, side, steps = 1, lay = false; breakFunc = ()->false)
    k = 0
    for _ in 1:steps 
        if isborder(robot, side) || breakFunc()
            return k
        end
        move!(robot, side)
        if lay
            putmarker!(robot)
        end
        k += 1
    end
    return k
end

#двигается до стены, если lay = true, то оставляет след из маркеров
function goWall(robot, side, lay = false)
    k = 0
    while !isborder(robot, side)
        k += 1
        move!(robot, side)
        if lay
            putmarker!(robot)
        end
    end
    return k
end

#передвигает робота в угол; возвращает список шагов чтобы вернуться домой
function goUgl(robot, corner = (Nord, West))
    moves = []
    while true
        for side in corner
            move = (side, goWall(robot, side))
            push!(moves, move)
            if issubset(corner, GetBorders(robot))
                return moves
            end
        end
    end
end

#выполняет список шагов; шаг = (сторона света; кол-во шагов)
function goPath(robot, path; reversePath = false)
    if !reversePath
        for cmd in path
            goSteps(robot, cmd[1], cmd[2])
        end
    else
        for cmd in reverse(path)
            goSteps(robot, rotate(cmd[1], 2), cmd[2])
        end
    end
end

#возвращается домой из любой клетки поля(moves- список шагов из дома в угол)
function goHome(robot, moves, corner = (Nord, West))
    goUgl(robot, corner)
    goPath(robot, moves, reversePath = true)
end

#шатается влево-вправо, пока stop_condition не вернет true
function shuttle!(stop_condition::Function, robot, side)
    metWall = false
    steps = 0
    addStep = false
    while true
        walked = goSteps(robot, side, steps)
        if stop_condition()
            return (side, steps)
        end
        if walked == steps
            goSteps(robot, rotate(side, 2), steps)
        else
            goSteps(robot, rotate(side, 2), walked)
            if metWall
                return ()
            end
            metWall = true
        end
        if addStep
            steps += 1
        end
        addStep = !addStep
        if !metWall
            side = rotate(side, 2)
        end
    end
end


#идет по спирали пока stop_condition не вернет true
function spiral!(stop_condition::Function, robot)
    steps = 1
    side = Nord
    while true
        side = rotate(side,1)
        goSteps(robot, side, steps, breakFunc = stop_condition)
        if stop_condition()
            break
        end
        side = rotate(side,1)
        goSteps(robot, side, steps, breakFunc = stop_condition)
        if stop_condition()
            break
        end
        steps += 1
    end
end

#двигается до того, как stop_condition возвращает true
function goUntil(stop_condition::Function, robot, side)
    k=0
    while !stop_condition()
        move!(robot, side)
        k+=1
    end
    return k
end

#идет вперед на 1 шаг, даже если перед ним стена; возвращает путь, который был пройден
function moveNav(robot, side)
    if !isborder(robot, side)
        move!(robot, side)
        return (side, 1)
    end
    path = []
    startPath = shuttle!(()->!isborder(robot, side), robot, rotate(side, 1))
    if startPath == ()
        return []
    end
    push!(path, startPath)
    move!(robot, side)
    throughPath = (side, goUntil(()->!isborder(robot, rotate(startPath[1], 2)), robot, side)+1)
    push!(path, throughPath)
    backPath = (rotate(startPath[1], 2), startPath[2])
    goSteps(robot, backPath[1], backPath[2])
    push!(path, backPath)
    if throughPath[2] > 1
        push!(path, (rotate(side, 2), goSteps(robot, rotate(side, 2), throughPath[2]-1)))
    end
    return path
end

#идет вперед на steps шагов, даже если перед ним стена; возвращает (true, path)
function goStepsNav(robot, side, steps = 1; moveType = ()->moveNav(robot, side), breakFunc = ()->false)
    path = []
    curSteps = 0
    for _ in 1:steps
        if breakFunc()
            return (true, path)
        end
        if isborder(robot, side)
            push!(path, (side, curSteps))
            curSteps = 0
            startPath = moveType()
            if startPath == []
                return (false, path)
            end
            append!(path, startPath)
        else
            move!(robot, side)
            curSteps += 1
        end
    end
    if curSteps != 0
        push!(path, (side, curSteps))
    end
    return (true, path)
end

# проходит все поле, но может обходить внутренние стены
function snakeNav(robot, sides)
    side = sides[1]
    height = goWall(robot, side)
    side = rotate(side, 2)
    while true
        goStepsNav(robot, side, height)
        if !isborder(robot, sides[2])
            move!(robot, sides[2])
        else
            break
        end
        side = rotate(side, 2)
    end
end

# спираль, но проходит стены
function spiralNav(stop_condition::Function, robot)
    steps = 1
    side = Nord
    while true
        side = rotate(side,1)
        goStepsNav(robot, side, steps, breakFunc = stop_condition)
        if stop_condition()
            break
        end
        side = rotate(side,1)
        goStepsNav(robot, side, steps, breakFunc = stop_condition)
        if stop_condition()
            break
        end
        steps += 1
    end
end