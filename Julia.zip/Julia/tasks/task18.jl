#include("MainFuncs.jl")
#robot = Robot(animate = true)

using HorizonSideRobots
function task18(robot)
    spiralNav(()->ismarker(robot), robot)
end
#task18(robot)