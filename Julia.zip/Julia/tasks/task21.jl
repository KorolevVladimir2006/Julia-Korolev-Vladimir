#include("MainFuncs.jl")
#robot = Robot(animate = true)
using HorizonSideRobots
function task21(robot,side1,side2 = rotate(side1,1))
    if isborder(robot,side1)
        move!(robot,side2)
        task21(robot,side1)
        move!(robot,rotate(side2,2))
    else move!(robot, side1)
    end
end
#task21(robot,side) side - произвольная