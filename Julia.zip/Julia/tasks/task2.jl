#include("MainFuncs.jl")
#robot = Robot(animate = true)
using HorizonSideRobots
function task2(robot)
    moves = goUgl(robot)
    for side in [Ost, Sud, West, Nord]
        goWall(robot, side, true)
    end
    goHome(robot, moves)
end
#task2(robot)