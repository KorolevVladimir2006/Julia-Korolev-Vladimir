#include("MainFuncs.jl")
#robot = Robot(animate = true)

using HorizonSideRobots
function task16(robot)
    shuttle!(()->!isborder(robot,Nord),robot,Ost)
end
#task16(robot)