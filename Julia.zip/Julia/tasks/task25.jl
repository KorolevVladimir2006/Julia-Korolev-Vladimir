#include("MainFuncs.jl")
#robot = Robot(animate = true)
using HorizonSideRobots
function task25a(robot,side)
    putmarker!(robot)
    if !isborder(robot,side)
        move!(robot,side)
        task25b(robot,side)
    end
end
function task25b(robot,side)
    if !isborder(robot,side)
        move!(robot,side)
        task25a(robot,side)
    end
end
#task25a(robot,side) side - произвольная
#task25b(robot,side) side - произвольная