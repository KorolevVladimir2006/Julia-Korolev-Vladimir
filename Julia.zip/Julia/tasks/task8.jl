#include("MainFuncs.jl")
#robot = Robot(animate = true)

using HorizonSideRobots
function task8(robot)
    spiral!(()->ismarker(robot), robot)
end
#task8(robot)