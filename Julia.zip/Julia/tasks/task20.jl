#include("MainFuncs.jl")
#robot = Robot(animate = true)
using HorizonSideRobots
function task20(robot,side)
    if isborder(robot,side)
        putmarker!(robot)
    else
        move!(robot,side)
        task20(robot,side)
        move!(robot,rotate(side,2))
    end
end
#task20(robot,side) side - произвольная