#robot = Robot(animate = true)
using HorizonSideRobots
function task19(robot,side)
    if !isborder(robot,side)
        move!(robot,side)
        task19(robot,side)
    end
end
#task19(robot,side) side - произвольная