#include("MainFuncs.jl")
#robot = Robot(animate = true)
using HorizonSideRobots

# посчитать количество стен в одной строчке
function countInLine(robot, side, gap)
    wallCount = 0
    currentGap = 0
    isWall = false
    while !isborder(robot, side)
        if !isborder(robot, Nord)
            currentGap+=1
            if currentGap>gap && isWall
                wallCount += 1
                isWall = false
            end
        else
            isWall = true
            currentGap = 0
        end
        move!(robot, side)
    end
    if isWall
        wallCount += 1
    end
    return wallCount
end

# посчитать количество стен во всем поле
function countHorizontalWall(robot, gap = 0)
    k = 0
    moves = goUgl(robot)
    move!(robot, Sud)
    side = Ost
    while true
        k += countInLine(robot, side, gap)
        if !isborder(robot, Sud)
            move!(robot, Sud)
            side = rotate(side, 2)
        else
            break
        end
    end
    goHome(robot,moves)
    return k
end

task11(robot) = countHorizontalWall(robot, 0)
task12(robot) = countHorizontalWall(robot, 1)

#task11(robot)
#task12(robot)