#include("MainFuncs.jl")
#robot = Robot(animate = true)
using HorizonSideRobots
function task23(robot, side, flag = false)
    if !isborder(robot,side) && !flag
        move!(robot,side)
        task23(robot,side)
        move!(robot,side)
    elseif !isborder(robot, rotate(side,2))
        move!(robot,rotate(side,2))
        task23(robot,side,true)
    else return end
end
#task23(robot,side) side - произвольная