#include("MainFuncs.jl")
#robot = Robot(animate = true)
using HorizonSideRobots
function task22(robot, side, steps = 0, flag = false)
    if isborder(robot, side) && !flag
        flag = true
        side = rotate(side, 2)
        steps *= 2
    end
    if steps == 0 && flag
        return true
    end
    if isborder(robot, side) && flag
        return false
    end
    move!(robot, side)
    if !flag
        steps += 1
    else
        steps -= 1
    end
    task22(robot, side, steps, flag)
end
#task22(robot,side) side - произвольная