#include("MainFuncs.jl")
#robot = Robot(animate = true)
using HorizonSideRobots
function task24_1(robot,side)
    if !isborder(robot,side)
        move!(robot,side)
        task24_2(robot,side)
        move!(robot,rotate(side,2))
    end
    return
end
function task24_2(robot,side)
    if !isborder(robot,side)
        move!(robot,side)
        task24_1(robot,side)
    end
    return
end
#task24_1(robot,side) side - произвольная