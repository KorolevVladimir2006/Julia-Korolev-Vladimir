#include("MainFuncs.jl")
#robot = Robot(animate = true)
using HorizonSideRobots

# рисует один квадрат с заданным размером n * n
function DrawSquare(robot, size)
    k = 0
    for i in 1:size
        putmarker!(robot)
        goSteps(robot, West, goSteps(robot, Ost, size-1, true))
        if i < size && !isborder(robot, Nord)
            move!(robot, Nord)
            k += 1
        end
    end
    goSteps(robot, Sud, k)
end

function task10(robot, n, flag = true)
    moves = goUgl(robot, (Sud, West))
    k = 0
    while true
        if flag
            DrawSquare(robot, n)
        end
        flag = !flag
        if goSteps(robot, Ost, n) != n
            goWall(robot, West)
            if goSteps(robot, Nord, n) != n
                break
            end
            k += 1
            flag = k%2 == 0
        end
    end
    goHome(robot, moves, (Sud, West))
end
#task10(robot, size)