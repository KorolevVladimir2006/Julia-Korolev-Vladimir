#include("MainFuncs.jl")
#robot = Robot(animate = true)

using HorizonSideRobots
function task17(robot)
    spiral!(()->ismarker(robot), robot)
end
#task17(robot)