#include("MainFuncs.jl")
#robot = Robot(animate = true)

using HorizonSideRobots
function task7(robot)
    shuttle!(()->!isborder(robot,Nord),robot,Ost)
end
#task7(robot)