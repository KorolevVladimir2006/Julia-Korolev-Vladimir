#include("MainFuncs.jl")
#robot = Robot(animate = true)
using HorizonSideRobots
function task3(robot)
    moves = goUgl(robot)
    side = Ost
    while true
        putmarker!(robot)
        goWall(robot, side, true)
        side = rotate(side,2)
        if !isborder(robot, Sud)
            move!(robot, Sud)
        else
            break
        end
    end
    goHome(robot, moves)
end
#task3(robot)