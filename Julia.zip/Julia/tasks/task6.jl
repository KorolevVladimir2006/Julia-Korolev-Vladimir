#include("MainFuncs.jl")
#robot = Robot(animate = true)
#include("CordRobot.jl")

using HorizonSideRobots

function task6a(robot)
    moves = goUgl(robot)
    [goWall(robot, side, true) for side = [Ost, Sud, West, Nord]]
    goHome(robot, moves)
end

# если координата x или y как у начальной точки, то ставим маркер
function isHomeCoord(robot)
    if (robot.x == 0) || (robot.y == 0)
        putmarker!(robot)
    end
end

function task6b(robot)
    robot = CoordRobot(robot)
    moves = goUgl(robot)
    robot.update = ()->isHomeCoord(robot)
    for side in [Ost, Sud, West, Nord]
        goWall(robot, side)
    end
    robot.allowPaint = false
    goHome(robot, moves)
end

#task6a(robot)
#task6b(robot)