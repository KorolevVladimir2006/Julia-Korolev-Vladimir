#include("MainFuncs.jl")
#robot = Robot(animate = true)
#include("CordRobot.jl")
using HorizonSideRobots

#если у координаты abs(x) == abs(y), то координата лежит по диагонали от начла, значит ставим марку
function markDiagonal(robot)
    if abs(robot.x) == abs(robot.y) != 0
        putmarker!(robot)
    end
end

function task15(robot)
    robot = CoordRobot(robot)
    home = goUgl(robot)
    SetUpdateFunc(robot, ()->markDiagonal(robot))
    snakeNav(robot, (Sud, Ost))
    goHome(robot, home)
end
#task15(robot)