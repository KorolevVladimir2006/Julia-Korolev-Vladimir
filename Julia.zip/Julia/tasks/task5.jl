#include("MainFuncs.jl")
#robot = Robot(animate = true)
using HorizonSideRobots

# функция для рисования внутреннего периметра
function OuterPerimeter(robot)
    while true
        side = GetBorders(robot)[1]
        putmarker!(robot)
        move!(robot, rotate(side,1))
        if ismarker(robot)
            break
        end
        if lastindex(GetBorders(robot)) == 0
            putmarker!(robot)
            move!(robot, side)
        end
    end
end

function task5(robot)
    moves = goUgl(robot)
    [goWall(robot, side, true) for side = [Ost, Sud, West, Nord]]
    height = goWall(robot, Sud)
    goWall(robot, Nord)
    while !isborder(robot, Ost)
        move!(robot, Ost)
        length = goWall(robot, Sud)
        if length !=height
            OuterPerimeter(robot)
            break
        end
        goWall(robot, Nord)
    end
    goHome(robot, moves)
end
#task5(robot)
