#include("MainFuncs.jl")
#robot = Robot(animate = true)
#include("CordRobot.jl")
using HorizonSideRobots

# ставит в клетку марку, если четность как у начальной 
function chetChess(robot, homeParity)
    if (robot.x+robot.y)%2 == homeParity
        putmarker!(robot)
    end
end

function task13_14(robot)
    robot = CoordRobot(robot)
    moves = goUgl(robot)
    resetCoords(robot)
    parity = sum(goHomeCoords(moves))%2
    SetUpdateFunc(robot, ()->chetChess(robot, parity))
    snakeNav(robot, (Ost, Sud))
    goHome(robot, moves)
end
#task13_14(robot)