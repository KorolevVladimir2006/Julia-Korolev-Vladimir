#include("MainFuncs.jl")
#robot = Robot(animate = true)
using HorizonSideRobots
function task1(robot)
    for side in [Ost, Sud, West, Nord]
        steps = goWall(robot, side, true)
        goSteps(robot, rotate(side, 2), steps)
    end
end
#task1(robot)